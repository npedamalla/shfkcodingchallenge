package com.shutterfly.ShutterFly;

import java.util.Scanner;

public class App

{
	

	public static void main(String[] args)

	{
		try{
		System.out.println("Enter your absolute paths of <inputFile> and <outputDir>");
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);		
		String inputFileDir = scanner.nextLine();
		String outputFileDir = scanner.nextLine();
		//System.out.println(propFileDir);
		
	
		
		new TopXSimpleLTVCustomers( inputFileDir, outputFileDir);
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}
