package com.shutterfly.ShutterFly;

public class Customer {
	
	String custKey ;
	String custEventTime;
	String custName ;


}
