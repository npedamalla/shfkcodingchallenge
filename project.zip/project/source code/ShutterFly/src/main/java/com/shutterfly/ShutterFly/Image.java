package com.shutterfly.ShutterFly;

public class Image {
	
	String imageIdKey;
	String imageEventTime;
	String imageCustKey ;

}
