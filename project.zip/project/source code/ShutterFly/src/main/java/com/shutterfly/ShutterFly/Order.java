package com.shutterfly.ShutterFly;

public class Order {
	
	String orderIdKey ;
	String orderEventTime;
	String orderCustKey ;
	String orderTotalAmnt ;

}
