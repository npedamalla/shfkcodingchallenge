package com.shutterfly.ShutterFly;

public class SiteVisit {
	
	String pageIdKey ;
	String pageEventTime;
	String pageCustkey ;

}
