package com.shutterfly.ShutterFly;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.util.Collections;
import java.util.Date;



public class TopXSimpleLTVCustomers {

	public TopXSimpleLTVCustomers() {

	}

	HashMap<String, ArrayList<Order>> orderListMap = new HashMap<String, ArrayList<Order>>();
	HashMap<String, ArrayList<Customer>> custListMap = new HashMap<String, ArrayList<Customer>>();
	HashMap<String, ArrayList<Image>> imageListMap = new HashMap<String, ArrayList<Image>>();
	HashMap<String, ArrayList<SiteVisit>> pageListMap = new HashMap<String, ArrayList<SiteVisit>>();
	
	//OutputFileCreator outFile = new OutputFileCreator();
	
	String outputFileDir = "";
	
	public TopXSimpleLTVCustomers(String propFileDir,String outputFileDir1) {
		
		outputFileDir = outputFileDir1;
		dataIngestion(propFileDir);
		simpleLVTCaluculation();

	}

	private Double simpleLVTCaluculation() {

		ArrayList<Double> averagOfVariables = averagOfVariables();

		averagOfVariables.get(1);
		averagOfVariables.get(2);
		averagOfVariables.get(3);

		Double simpleLVTVal = (52 * averagOfVariables.get(3)) * 20;

		
		System.out.println("According to given Formula SLVT 52(a)Xt, given t=20 years(from sheet) 'a' is average Customer expenditure"+ simpleLVTVal);
		
		writeToFile("According to given Formula SLVT 52(a)Xt, given t=20 years(from sheet) 'a' is average Customer expenditure"+ simpleLVTVal);
		
		return simpleLVTVal;

	}

	

	private ArrayList<Double> averagOfVariables() {

		ArrayList<Double> amountList = new ArrayList<Double>();
		ArrayList<Order> alOrder = new ArrayList<Order>();
		ArrayList<String> custKeyDatestr = new ArrayList<String>();
		Set<String> custKeySet = custListMap.keySet();
		for (Object custKey : custKeySet) {
			alOrder = orderListMap.get(custKey);
		}
		for (int i = 0; i < alOrder.size(); i++) {
			custKeyDatestr.add(alOrder.get(i).orderCustKey);
			amountList.add(Double.parseDouble(alOrder.get(i).orderTotalAmnt));
		}

		Double avgExpen = avgCal(amountList);
		Double avgCustVisits = noOfDaysVisited(custKeyDatestr);

		System.out.println("Average of Customer Expenditure::" + avgExpen);		
		writeToFile("Average of Customer Expenditure::" + avgExpen);
		
		System.out.println("Average of Customer Visits::" + avgCustVisits);
		writeToFile("Average of Customer Visits::" + avgCustVisits);
		
		System.out.println("Average of Customer Perweek::" + (avgCustVisits * avgExpen));
		writeToFile("Average of Customer Perweek::" + (avgCustVisits * avgExpen));
		
		amountList.add(1, avgExpen);
		amountList.add(2, avgCustVisits);
		amountList.add(3, (avgCustVisits * avgExpen));

		return amountList;

	}

	private Double noOfDaysVisited(ArrayList<String> custKeyDatestr) {
		Set<String> custKeySet = custListMap.keySet();
		Double sumCount = 0.00;
		for (Object custKey : custKeySet) {

			sumCount = sumCount + Collections.frequency(custKeyDatestr, custKey);
		}
		return (Double) (sumCount / custKeySet.size());

	}

	private Double avgCal(ArrayList<Double> amountList) {

		Double averageSum = 0.00;
		for (int i = 0; i < amountList.size(); i++) {
			averageSum = averageSum + amountList.get(i);
		}
		return averageSum / amountList.size();
	}

	private void dataIngestion(String filePath) {

		ArrayList<Order> orderList = new ArrayList<Order>();
		ArrayList<Customer> custList = new ArrayList<Customer>();
		ArrayList<SiteVisit> pageList = new ArrayList<SiteVisit>();
		ArrayList<Image> imageList = new ArrayList<Image>();

		JSONParser parser = new JSONParser();

		try {

			JSONArray eventsJsonArray = (JSONArray) parser.parse(new FileReader(filePath));

			for (Object obj : eventsJsonArray) {

				JSONObject eventJsonObj = (JSONObject) obj;

				String type = (String) eventJsonObj.get("type");

				if (type.equals("CUSTOMER")) {

					Customer customer = new Customer();

					customer.custKey = (String) eventJsonObj.get("key");
					customer.custEventTime = (String) eventJsonObj.get("event_time");
					customer.custEventTime = dateExtractor(customer.custEventTime);
					customer.custName = (String) eventJsonObj.get("last_name");

					custList.add(customer);

					custListMap.put(customer.custKey, custList);

				}

				if (type.equals("SITE_VISIT")) {

					SiteVisit page = new SiteVisit();

					page.pageIdKey = (String) eventJsonObj.get("key");
					page.pageEventTime = (String) eventJsonObj.get("event_time");
					page.pageCustkey = (String) eventJsonObj.get("customer_id");

					page.pageEventTime = dateExtractor(page.pageEventTime);
					pageList.add(page);
					pageListMap.put(page.pageCustkey, pageList);

				}

				if (type.equals("IMAGE")) {

					Image image = new Image();

					image.imageIdKey = (String) eventJsonObj.get("key");
					image.imageEventTime = (String) eventJsonObj.get("event_time");
					image.imageCustKey = (String) eventJsonObj.get("customer_id");

					image.imageEventTime = dateExtractor(image.imageEventTime);
					imageList.add(image);

					imageListMap.put(image.imageCustKey, imageList);

				}

				if (type.equals("ORDER")) {

					Order order = new Order();

					order.orderIdKey = (String) eventJsonObj.get("key");
					order.orderEventTime = (String) eventJsonObj.get("event_time");
					order.orderCustKey = (String) eventJsonObj.get("customer_id");
					order.orderTotalAmnt = (String) eventJsonObj.get("total_amount");

					order.orderTotalAmnt = order.orderTotalAmnt.replaceAll(" USD", "");

					order.orderEventTime = dateExtractor(order.orderEventTime);


					if (orderListMap.get(order.orderCustKey) != null) {
						ArrayList<Order> temp = orderListMap.get(order.orderCustKey);
						temp.add(order);
						orderListMap.remove(order.orderCustKey);
						orderListMap.put(order.orderCustKey, temp);

					} else {
						orderList.add(order);
						orderListMap.put(order.orderCustKey, orderList);
					}

				}

			} // end of for loop

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} catch (ParseException e) {

			e.printStackTrace();
		}


	}

	private String dateExtractor(String eventTime) {

		String[] firstDate = eventTime.split("T");
		DateFormat formatter;
		Date date;
		// Calendar calInst = GregorianCalendar.getInstance();
		String dateStr = "";

		try {

			formatter = new SimpleDateFormat("yyyy-MM-dd");
			date = (Date) formatter.parse(firstDate[0]);
			dateStr = formatter.format(date);
			// System.out.println(dateStr);
		}

		catch (java.text.ParseException e) {
			e.getMessage();

		}
		return dateStr;

	}
	
	private void writeToFile(String content) {
		
		 BufferedWriter bw = null ;
		 FileWriter fw = null;
		
		try{
		
		String path = outputFileDir;
		Date date = new Date() ;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy") ;
		String curDate =dateFormat.format(date);
		curDate = "output_"+curDate+".txt";
		
		File file = new File(path+curDate);
		//BufferedWriter bw = null;
		 
       if (!file.exists()) {
           file.createNewFile();
       }
		
 
		
        fw = new FileWriter(file.getAbsoluteFile(),true);
        bw = new BufferedWriter(fw);           
        bw.write("\n"+content);            
      
		
		} catch(Exception e){
           System.out.println(e);
       } finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}
		}

	}

		


}
